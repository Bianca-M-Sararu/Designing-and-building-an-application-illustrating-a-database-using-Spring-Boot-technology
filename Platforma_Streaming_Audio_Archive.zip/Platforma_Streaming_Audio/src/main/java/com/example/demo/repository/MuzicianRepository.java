package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Muzician;

public interface MuzicianRepository extends JpaRepository<Muzician, Long>{

}
//muzician repository are in spate niste functii find all()-> select * from tabela


