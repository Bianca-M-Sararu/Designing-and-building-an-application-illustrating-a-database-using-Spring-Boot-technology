package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Muzician;

public interface MuzicianService {

	List<Muzician> getAllMuzicieni();
	
	Muzician saveMuzician(Muzician muzician);
	
	Muzician getMuzicianById(Long idmuzician);
	
	Muzician updateMuzician(Muzician muzician);
	
	void deleteMuzicianById(Long idmuzician);
}