package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Album;

public interface AlbumService {
	
	List<Album> getAllAlbume();
	
	Album saveAlbum(Album album);
	
	Album getAlbumById(Long idalbum);
	
	Album updateAlbum(Album album);
	
	void deleteAlbumById(Long idalbum);
}