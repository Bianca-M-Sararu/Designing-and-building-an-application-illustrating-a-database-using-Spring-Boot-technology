package com.example.demo.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Muzician;
import com.example.demo.repository.MuzicianRepository;
import com.example.demo.service.MuzicianService;

@Service

public class MuzicianServiceImpl implements MuzicianService{

	private MuzicianRepository MuzicianRepository;
	
	public MuzicianServiceImpl(MuzicianRepository MuzicianRepository) {
		super();
		this.MuzicianRepository = MuzicianRepository;
	}

	@Override
	public List<Muzician> getAllMuzicieni() {
		return MuzicianRepository.findAll();
	}

	@Override
	public Muzician saveMuzician(Muzician Muzician) {
		return MuzicianRepository.save(Muzician);
	}

	@Override
	public Muzician getMuzicianById(Long idmuzician) {
		return MuzicianRepository.findById(idmuzician).get();
	}

	@Override
	public Muzician updateMuzician(Muzician Muzician) {
		return MuzicianRepository.save(Muzician);
	}

	@Override
	public void deleteMuzicianById(Long idmuzician) {
		MuzicianRepository.deleteById(idmuzician);	
	}
}