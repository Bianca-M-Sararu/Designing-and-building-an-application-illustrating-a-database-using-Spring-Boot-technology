package com.example.demo.entity;

import java.sql.Date;

import jakarta.persistence.*;

@Entity
@Table(name = "melodii")

public class Melodie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idmelodie;
	
	@ManyToOne
    @JoinColumn(name = "idmuzician", nullable = false)
    private Muzician muzician;
	
	@ManyToOne
    @JoinColumn(name = "idalbum", nullable = false)
    private Album album;

	@Column(name = "nume", nullable = false)
	private String nume;
	
	@Column(name = "durata_minute", nullable = false)
	private Integer durata_minute;

	@Column(name = "data_lansare")
	private Date data_lansare;
	
	@Column(name = "premiu", nullable = false)
	private String premiu;


	public Melodie() {

	}

	public Melodie(Muzician muzician, Album album, String nume, Integer durata_minute, Date data_lansare, String premiu) {
		super();
		this.muzician = muzician;
		this.album = album;
		this.nume = nume;
		this.durata_minute =  durata_minute;
		this.data_lansare = data_lansare;
		this.premiu = premiu;
	}

	public Long getIdmelodie() {
		return this.idmelodie;
	}

	public void setIdmelodie(Long idmelodie) {
		this.idmelodie = idmelodie;
	}
	public Muzician getMuzician() {
		return this.muzician;
	}

	public void setMuzician(Muzician muzician) {
		this.muzician = muzician;
	}
	public Album getAlbum() {
		return this.album;
	}

	public void setAlbum(Album album) {
		this.album = album;
	}
	
	public String getNume() {
		return this.nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}
	
	public Integer getDurata_minute() {
		return this.durata_minute;
	}
	
	public void setDurata_minute(Integer durata_minute) {
		this.durata_minute = durata_minute;
	}

	public Date getData_lansare() {
		return this.data_lansare;
	}
	
	public void setData_lansare(Date data_lansare) {
		this.data_lansare = data_lansare;
	}
	
	public String getPremiu() {
		return this.premiu;
	}

	public void setPremiu(String premiu) {
		this.premiu = premiu;
	}

}