package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Melodie;
import com.example.demo.service.MelodieService;

import com.example.demo.entity.Muzician;
import com.example.demo.repository.AlbumRepository;
import com.example.demo.repository.MuzicianRepository;
import com.example.demo.entity.Album;

@Controller

public class MelodieController {

	private MelodieService melodieService;
	
	@Autowired
	private MuzicianRepository muzicianRepo;
	
	@Autowired
	private AlbumRepository albumRepo;

	public MelodieController(MelodieService melodieService) {
		super();
		this.melodieService = melodieService;
	}
	
	@GetMapping("/melodii")
	public String listMelodii(Model model) {
		model.addAttribute("melodii", melodieService.getAllMelodii());
		return "melodii";
	}
	
	@GetMapping("/melodii/new")
	public String createMelodieForm(Model model) {
		List<Muzician> totimuzicienii = muzicianRepo.findAll();
		List<Album> toatealbumele= albumRepo.findAll();
		
		Melodie melodie = new Melodie();
		model.addAttribute("melodie", melodie);
		
		model.addAttribute("totimuzicienii", totimuzicienii);
		model.addAttribute("toatealbumele", toatealbumele);
		
		return "create_melodie";
		
	}
	
	@PostMapping("/melodii")
	public String saveMelodie(@ModelAttribute("melodie") Melodie melodie) {		
		melodieService.saveMelodie(melodie);
		return "redirect:/melodii";
	}
	
	@GetMapping("/melodii/edit/{idmelodie}")
	public String editMelodieForm(@PathVariable Long idmelodie, Model model) {
		List<Muzician> totimuzicienii = muzicianRepo.findAll();
		List<Album> toatealbumele = albumRepo.findAll();

		model.addAttribute("melodie", melodieService.getMelodieById(idmelodie));
		model.addAttribute("totimuzicienii", totimuzicienii);
		model.addAttribute("toatealbumele", toatealbumele);
		
		return "edit_melodie";
	}

	@PostMapping("/melodii/{idmelodie}")
	public String updateMelodie(@PathVariable Long idmelodie,
			@ModelAttribute("melodie") Melodie melodie,
			Model model) {
		
		Melodie melodieExistenta = melodieService.getMelodieById(idmelodie);
		melodieExistenta.setIdmelodie(idmelodie);
		melodieExistenta.setMuzician(melodie.getMuzician());
		melodieExistenta.setAlbum(melodie.getAlbum());
		melodieExistenta.setNume(melodie.getNume());
		melodieExistenta.setDurata_minute(melodie.getDurata_minute());
		melodieExistenta.setData_lansare(melodie.getData_lansare());
		melodieExistenta.setPremiu(melodie.getPremiu());

		melodieService.updateMelodie(melodieExistenta);
		return "redirect:/melodii";		
	}
	
	
	@GetMapping("/melodii/{idmelodie}")
	public String deleteMelodie(@PathVariable Long idmelodie) {
		melodieService.deleteMelodieById(idmelodie);
		return "redirect:/melodii";
	}	
}