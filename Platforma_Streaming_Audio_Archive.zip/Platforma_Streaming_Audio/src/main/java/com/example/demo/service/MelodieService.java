package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Melodie;


public interface MelodieService {

	List<Melodie> getAllMelodii();
	
	Melodie saveMelodie(Melodie melodie);
	
	Melodie getMelodieById(Long idmelodie);
	
	Melodie updateMelodie(Melodie melodie);
	
	void deleteMelodieById(Long idmelodie);
}