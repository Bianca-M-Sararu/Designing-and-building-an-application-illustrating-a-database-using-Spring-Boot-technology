package com.example.demo.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Album;
import com.example.demo.service.AlbumService;

@Controller

public class AlbumController {
	
	private AlbumService albumService;

	public AlbumController(AlbumService albumService) {
		super();
		this.albumService = albumService;
	}
	
	@GetMapping("/albume")
	public String listAlbume(Model model) { // aici nu cred ca este listMuzicieni ci listAlbume
		model.addAttribute("albume", albumService.getAllAlbume());
		return "albume";
	}
	
	@GetMapping("/albume/new")
	public String createAlbumForm(Model model) {
		
		Album album = new Album();
		model.addAttribute("album", album);
		return "create_album";
		
	}
	
	@PostMapping("/albume")
	public String saveAlbum(@ModelAttribute("album") Album album) {
		albumService.saveAlbum(album);
		return "redirect:/albume";
	}
	
	@GetMapping("/albume/edit/{idalbum}") // ai grija aici , daca e vreo problema , mai verifica aici
	public String editAlbumForm(@PathVariable Long idalbum, Model model) {
		model.addAttribute("album", albumService.getAlbumById(idalbum));
		return "edit_album";
	}

	@PostMapping("/albume/{idalbum}")
	public String updateAlbum(@PathVariable Long idalbum,
			@ModelAttribute("album") Album album,
			Model model) {
		
		Album albumExistent = albumService.getAlbumById(idalbum);
		albumExistent.setIdalbum(idalbum);
		albumExistent.setNume(album.getNume());
		albumExistent.setNumar_piese(album.getNumar_piese());
		albumExistent.setData_lansare(album.getData_lansare());
		albumExistent.setStil_muzical(album.getStil_muzical());
		
		albumService.updateAlbum(albumExistent);
		return "redirect:/albume";		
	}
	
	
	@GetMapping("/albume/{idalbum}")
	public String deleteAlbum(@PathVariable Long idalbum) {
		albumService.deleteAlbumById(idalbum);
		return "redirect:/albume";
	}	
}
