package com.example.demo.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Album;
import com.example.demo.repository.AlbumRepository;
import com.example.demo.service.AlbumService;

@Service


public class AlbumServiceImpl implements AlbumService{

	private AlbumRepository AlbumRepository;
	
	public AlbumServiceImpl(AlbumRepository AlbumRepository) {
		super();
		this.AlbumRepository = AlbumRepository;
	}

	@Override
	public List<Album> getAllAlbume() {
		return AlbumRepository.findAll();
	}

	@Override
	public Album saveAlbum(Album Album) {
		return AlbumRepository.save(Album);
	}

	@Override
	public Album getAlbumById(Long idalbum) {
		return AlbumRepository.findById(idalbum).get();
	}

	@Override
	public Album updateAlbum(Album Album) {
		return AlbumRepository.save(Album);
	}

	@Override
	public void deleteAlbumById(Long idalbum) {
		AlbumRepository.deleteById(idalbum);	
	}
}