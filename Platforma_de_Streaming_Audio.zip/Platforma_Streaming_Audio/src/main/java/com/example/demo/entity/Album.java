package com.example.demo.entity;

import java.sql.Date;
import java.util.Set;

import jakarta.persistence.*;

@Entity
@Table(name = "albume")

public class Album {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idalbum;

	@Column(name = "nume", nullable = false)
	private String nume;

	@Column(name = "numar_piese", nullable = false)
	private Integer numar_piese;

	@Column(name = "data_lansare")
	private Date data_lansare;
	
	@Column(name = "stil_muzical", nullable = false)
	private String stil_muzical;
	
	@OneToMany(mappedBy="album", cascade = CascadeType.ALL,orphanRemoval = true)
	private Set<Melodie> melodie;

	public Album() {

	}

	public Album(String nume, Integer numar_piese, Date data_lansare, String stil_muzical, Set<Melodie> m) {
		super();
		this.nume = nume;
		this.numar_piese=numar_piese;
		this.data_lansare = data_lansare;
		this.stil_muzical = stil_muzical;
		this.melodie = m;
	}

	public Long getIdalbum() {
		return idalbum;
	}

	public void setIdalbum(Long idalbum) {
		this.idalbum = idalbum;
	}

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public Integer getNumar_piese() {
		return numar_piese;
	}

	public void setNumar_piese(Integer numar_piese) {
		this.numar_piese = numar_piese;
	}
	
	public Date getData_lansare() {
		return this.data_lansare;
	}
	
	public void setData_lansare(Date data_lansare) {
		this.data_lansare = data_lansare;
	}

	public String getStil_muzical() {
		return stil_muzical;
	}

	public void setStil_muzical(String stil_muzical) {
		this.stil_muzical = stil_muzical;
	}
	
	public Set<Melodie> getMelodie() {
		return this.melodie;
	}

	public void setMelodie(Set<Melodie> melodie) {
		this.melodie = melodie;
	}
}