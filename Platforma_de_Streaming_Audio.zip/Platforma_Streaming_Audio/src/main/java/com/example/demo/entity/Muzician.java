package com.example.demo.entity;

import java.util.Set;

import jakarta.persistence.*;

@Entity
@Table(name = "muzicieni")

public class Muzician {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idmuzician;

	@Column(name = "nume", nullable = false)
	private String nume;

	@Column(name = "prenume", nullable = false)
	private String prenume;

	@Column(name = "nume_scena", nullable = false)
	private String nume_scena;
	
	@Column(name = "an_inceput_activitate", nullable = false)
	private Integer an_inceput_activitate;
	
	@Column(name = "varsta", nullable = false)
	private Integer varsta;
	
	@Column(name = "stil_muzical")
	private String stil_muzical;
	
	@OneToMany(mappedBy="muzician", cascade = CascadeType.ALL,orphanRemoval = true)// orphanRemoval inseamna stergerea in cascada sau cascadarea
	private Set<Melodie> melodie;

	public Muzician() {

	}

	public Muzician(String nume, String prenume, String nume_scena, Integer an_inceput_activitate, Integer varsta, String stil_muzical, Set<Melodie> m) {
		super();
		this.nume = nume;
		this.prenume = prenume;
		this.nume_scena = nume_scena;
		this.an_inceput_activitate = an_inceput_activitate;
		this.varsta = varsta;
		this.stil_muzical = stil_muzical;
		this.melodie = m;
	}

	public Long getIdmuzician() {
		return idmuzician;
	}

	public void setIdmuzician(Long idmuzician) {
		this.idmuzician = idmuzician;
	}

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public String getPrenume() {
		return prenume;
	}

	public void setPrenume(String prenume) {
		this.prenume = prenume;
	}

	public String getNume_scena() {
		return nume_scena;
	}

	public void setNume_scena(String nume_scena) {
		this.nume_scena = nume_scena;
	}
	
	public Integer getAn_inceput_activitate() {
		return an_inceput_activitate;
	}

	public void setAn_inceput_activitate(Integer an_inceput_activitate) {
		this.an_inceput_activitate = an_inceput_activitate;
	}
	
	public Integer getVarsta() {
		return varsta;
	}

	public void setVarsta(Integer varsta) {
		this.varsta = varsta;
	}
	
	public String getStil_muzical() {
		return stil_muzical;
	}

	public void setStil_muzical(String stil_muzical) {
		this.stil_muzical = stil_muzical;
	}
	
	public Set<Melodie> getMelodie() {
		return this.melodie;
	}

	public void setMelodie(Set<Melodie> melodie) {
		this.melodie = melodie;
	}
}