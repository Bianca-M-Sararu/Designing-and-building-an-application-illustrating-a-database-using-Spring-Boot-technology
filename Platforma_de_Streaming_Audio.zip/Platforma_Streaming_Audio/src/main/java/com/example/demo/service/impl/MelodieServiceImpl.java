package com.example.demo.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Melodie;
import com.example.demo.repository.MelodieRepository;
import com.example.demo.service.MelodieService;

@Service

public class MelodieServiceImpl implements MelodieService{

	private MelodieRepository MelodieRepository;
	
	public MelodieServiceImpl(MelodieRepository MelodieRepository) {
		super();
		this.MelodieRepository = MelodieRepository;
	}

	@Override
	public List<Melodie> getAllMelodii() {
		return MelodieRepository.findAll();
	}

	@Override
	public Melodie saveMelodie(Melodie Melodie) {
		return MelodieRepository.save(Melodie);
	}

	@Override
	public Melodie getMelodieById(Long idmelodie) {
		return MelodieRepository.findById(idmelodie).get();
	}

	@Override
	public Melodie updateMelodie(Melodie Melodie) {
		return MelodieRepository.save(Melodie);
	}

	@Override
	public void deleteMelodieById(Long idmelodie) {
		MelodieRepository.deleteById(idmelodie);	
	}
}