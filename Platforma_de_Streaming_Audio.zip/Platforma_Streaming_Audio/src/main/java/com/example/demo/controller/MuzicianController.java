package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Muzician;
import com.example.demo.service.MuzicianService;

@Controller

public class MuzicianController {
	
	private MuzicianService muzicianService;

	public MuzicianController(MuzicianService muzicianService) {
		super();
		this.muzicianService = muzicianService;
	}
	
	// metoda handler care se ocupa cu lista muzicienilor, returnarea si vizualizarea lor
	
	@GetMapping("/muzicieni")
	public String listMuzicieni(Model model) {
		model.addAttribute("muzicieni", muzicianService.getAllMuzicieni());
		return "muzicieni";
	}
	
	@GetMapping("/muzicieni/new")
	public String createMuzicianForm(Model model) {
		
		// creaza obiectul muzician pentru a stoca datele din formular
		Muzician muzician = new Muzician();
		model.addAttribute("muzician", muzician);
		return "create_muzician";
		
	}
	
	@PostMapping("/muzicieni")
	public String saveMuzician(@ModelAttribute("muzician") Muzician muzician) {
		muzicianService.saveMuzician(muzician);
		return "redirect:/muzicieni";
	}
	
	@GetMapping("/muzicieni/edit/{idmuzician}")
	public String editMuzicianForm(@PathVariable Long idmuzician, Model model) {
		model.addAttribute("muzician", muzicianService.getMuzicianById(idmuzician));
		return "edit_muzician";
	}

	@PostMapping("/muzicieni/{idmuzician}")
	public String updateMuzician(@PathVariable Long idmuzician,
			@ModelAttribute("muzician") Muzician muzician,
			Model model) {
		
		// preia muzicianul din baza de date dupa campul idmuzician
		
		Muzician muzicianExistent = muzicianService.getMuzicianById(idmuzician);
		muzicianExistent.setIdmuzician(idmuzician);
		muzicianExistent.setNume(muzician.getNume());
		muzicianExistent.setPrenume(muzician.getPrenume());
		muzicianExistent.setNume_scena(muzician.getNume_scena());
		muzicianExistent.setAn_inceput_activitate(muzician.getAn_inceput_activitate());
		muzicianExistent.setVarsta(muzician.getVarsta());
		muzicianExistent.setStil_muzical(muzician.getStil_muzical());
		
		// salveaza un obiect muzician modificat
		muzicianService.updateMuzician(muzicianExistent);
		return "redirect:/muzicieni";		
	}
	
	// metoda de tip handler folosita pentru a se ocupa cu cererea de stergere a muzicianului
	
	@GetMapping("/muzicieni/{idmuzician}")
	public String deleteMuzician(@PathVariable Long idmuzician) {
		muzicianService.deleteMuzicianById(idmuzician);
		return "redirect:/muzicieni";
	}	
}
